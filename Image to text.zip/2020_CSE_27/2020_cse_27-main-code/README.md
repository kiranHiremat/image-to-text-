# 2020_cse_27
Text Extraction and Recognition from Images

The aim of this project is to develop an Optical Capture Recognition (OCR) for Android based mobile devices. Scanned text documents, pictures stored in mobile phones having Android as operating system, and pictures taken by any Android device are the mainly focus of this application. This capstone project is divided into two parts, the desktop application, and the Android based application that I have implemented. The purpose of this application is to recognize text in scanned text documents, text images, and any picture taken by an Android based device in order to reuse it later. This application will allow its users to perform many actions in few minutes, such as copy text from these aforementioned documents and modify it, instead of wasting time on retyping it.

Guide: Mrs. Ranjitha K N

Team members:
Sai Kumar LS            1KS17CS069
Sandesh N               1KS17CS072
Varun Reddy             1KS17CS097
Vinay Biradar           1KS17CS099
